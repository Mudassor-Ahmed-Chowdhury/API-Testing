# API_Testing_Project
Consists of CRUD Operation, HTML and HTML Extra Report

Summary,
1. Base URL: https://restful-booker.herokuapp.com
2. CRUD operation.
3. Creating Tests.
4. Get data from pre-request to environment.
5. Get Random firstname, lastname, integer value.
6. Auto generate date.
7. Data validation check, e.t.c
8. Newman HTML & HTML Extra Report
